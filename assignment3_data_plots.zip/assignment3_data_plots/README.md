# DRL: Policy Based Methods

## Info:

In this repository you can see the results we got from running our experiments on the Catch environment. 

For each method we have two folders, one with the `.npy` files containing the results of the experiments and another one with the `.png` files containing the plots of the results.
